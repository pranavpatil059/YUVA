# VoltSense BEMS

Building energy management dashboard for a simulated commercial tower (Tower A). It shows how pre-cooling, battery storage and solar can shift load away from peak tariff hours while keeping occupants comfortable.

**Live demo:** https://voltsense-bems.onrender.com

## Demo login

| Operator ID | Password |
| --- | --- |
| `operator` | `voltsense123` |

The sign-in check runs in the browser and is for demonstration only. Replace it with a real authentication service before connecting to live building systems.

## What it shows

- **Overview:** 3D digital twin of the tower with live KPIs, load shifting and forecast charts. Drag the time slider to move through a simulated day.
- **Tariff and load shifting:** pre-cool, coast through the peak, recover on cheap units, with a breakdown by tariff band.
- **HVAC:** zone comfort scores, plant status against baseline, and a log of automatic and manual actions.
- **Forecasting:** load and occupancy forecasts, feature importance, and fault detection.
- **Savings:** what-if sliders for solar, battery, peak HVAC cut and setpoint, with payback and carbon avoided.

## Data

All figures are simulated for a demonstration building. The load forecaster was also checked on a public BDG2 hourly sample (6,553 rows, two buildings, 80/20 chronological split): MAPE 5.5%, against 5.31% for a previous-day baseline and 3.75% for a previous-week baseline. Grid emission factor of 0.82 kg CO2 per kWh is an assumption.

## Run locally

It is a single static file. Open `index.html` in a browser, or serve the folder:

```
python3 -m http.server 8000
```

Three.js and Chart.js load from cdnjs, so an internet connection is needed.

## Deploy on Render

Create a **Static Site** from this repo. Leave the build command empty and set the publish directory to `.`. Each push to `main` redeploys automatically.

## Planned deployment path

Sensors and meters, an edge gateway (BACnet, Modbus to MQTT), a cloud time-series store, forecasting services, then this dashboard. The prototype runs on simulated data.
